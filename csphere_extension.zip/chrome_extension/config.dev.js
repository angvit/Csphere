// export const BACKEND_URL = "http://127.0.0.1:8000";
// export const FRONTEND_URL = "http://localhost:3000";

export const BACKEND_URL = "https://csphere.feeltiptop.com";
export const FRONTEND_URL = "https://csphere.io";
export const DEPLOYED = true;